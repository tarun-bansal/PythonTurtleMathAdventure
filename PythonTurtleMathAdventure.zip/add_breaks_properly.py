#!/usr/bin/env python3
"""
Add 20-minute break points to sessions 03-12.
Inserts breaks before:
1. First exercise heading (contains "Exercise" or "Hands-on")
2. Math Connection heading
3. Challenge Problems heading
Updates parent note.
"""

import os
import re

def add_breaks_to_file(filepath):
    with open(filepath, 'r') as f:
        lines = f.readlines()

    # Convert to list of strings without newlines for easier processing
    lines = [line.rstrip('\n') for line in lines]

    # Find target line numbers
    first_exercise_idx = -1
    math_connection_idx = -1
    challenge_idx = -1
    parent_note_idx = -1

    for i, line in enumerate(lines):
        if first_exercise_idx == -1 and re.search(r'[Ee]xercise|[Hh]ands?-?[Oo]n', line) and line.startswith('## '):
            # Ensure it's not a header like "## 🎯 Learning Objectives" that might contain "exercise" in description
            # Simple check: heading should contain "Exercise" or "Hands-on"
            if 'Exercise' in line or 'Hands-on' in line:
                first_exercise_idx = i
        elif math_connection_idx == -1 and re.search(r'[Mm]ath [Cc]onnection', line) and line.startswith('## '):
            math_connection_idx = i
        elif challenge_idx == -1 and re.search(r'[Cc]hallenge [Pp]roblems', line) and line.startswith('## '):
            challenge_idx = i
        elif parent_note_idx == -1 and line.startswith('*Parent Note:'):
            parent_note_idx = i

    print(f"{os.path.basename(filepath)}: exercise@{first_exercise_idx}, math@{math_connection_idx}, challenge@{challenge_idx}, parent@{parent_note_idx}")

    # Insert breaks (working backwards to preserve indices)
    # Break messages
    break_template = """---

⏱️ **20-Minute Break Point**

*{message}*

---"""

    if challenge_idx != -1:
        # Check if already has break before
        if not (challenge_idx > 0 and '⏱️' in lines[challenge_idx-1]):
            break_text = break_template.format(message="Great work! You've learned the key concepts. Take a short break if you need one. When you're ready, try the challenge problems to test your skills!")
            lines.insert(challenge_idx, break_text)
            # Adjust other indices after insertion
            if math_connection_idx > challenge_idx:
                math_connection_idx += 1
            if first_exercise_idx > challenge_idx:
                first_exercise_idx += 1
            if parent_note_idx > challenge_idx:
                parent_note_idx += 1

    if math_connection_idx != -1:
        if not (math_connection_idx > 0 and '⏱️' in lines[math_connection_idx-1]):
            break_text = break_template.format(message="Great job! You've practiced with hands-on exercises. Take a short break if you need one. When you're ready, continue with the math connection and Scratch translation.")
            lines.insert(math_connection_idx, break_text)
            if first_exercise_idx > math_connection_idx:
                first_exercise_idx += 1
            if challenge_idx > math_connection_idx:
                challenge_idx += 1
            if parent_note_idx > math_connection_idx:
                parent_note_idx += 1

    if first_exercise_idx != -1:
        if not (first_exercise_idx > 0 and '⏱️' in lines[first_exercise_idx-1]):
            break_text = break_template.format(message="Great! You've learned the core concepts. Take a short break if you need one. When you're ready, continue with hands-on exercises to practice your new skills.")
            lines.insert(first_exercise_idx, break_text)
            if math_connection_idx > first_exercise_idx:
                math_connection_idx += 1
            if challenge_idx > first_exercise_idx:
                challenge_idx += 1
            if parent_note_idx > first_exercise_idx:
                parent_note_idx += 1

    # Update parent note
    if parent_note_idx != -1:
        line = lines[parent_note_idx]
        # Check if already contains chunk mention
        if "20-minute chunks" not in line:
            lines[parent_note_idx] = "*Parent Note: This session is designed in 20-minute chunks (marked with ⏱️ break points). Total session time: 45-60 minutes. " + line[len("*Parent Note: "):]
        else:
            # Already has chunk mention, ensure it's not duplicated
            # Simple fix: replace with standard prefix
            lines[parent_note_idx] = "*Parent Note: This session is designed in 20-minute chunks (marked with ⏱️ break points). Total session time: 45-60 minutes. " + line.split("Total session time: 45-60 minutes. ")[-1] if "Total session time: 45-60 minutes. " in line else line

    # Write back
    with open(filepath, 'w') as f:
        f.write('\n'.join(lines))

def main():
    for session_num in range(3, 13):
        filepath = os.path.join("sessions", f"session{session_num:02d}", f"session{session_num:02d}.md")
        if os.path.exists(filepath):
            add_breaks_to_file(filepath)
        else:
            print(f"Missing {filepath}")

if __name__ == "__main__":
    main()