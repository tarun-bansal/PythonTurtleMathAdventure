#!/usr/bin/env python3

with open('sessions/session10/session10.md', 'r') as f:
    lines = f.readlines()

# Convert to 0-indexed
start = 44  # line 45 (since 0-index)
end = 100   # line 101 inclusive

new_content = """## 🎄 Exercise 1: Fractal Tree

Draw a tree where each branch splits into smaller branches:

**Start with this simpler version if recursion is new to you:**

```python
import turtle

t = turtle.Turtle()
t.speed(0)
t.left(90)
t.penup()
t.goto(0, -200)
t.pendown()

def simple_tree(size):
    if size < 10:  # Stop when branches get small
        return
    t.forward(size)
    t.left(30)
    simple_tree(size * 0.7)  # Smaller branch
    t.right(60)
    simple_tree(size * 0.7)  # Smaller branch
    t.left(30)
    t.backward(size)

simple_tree(100)
turtle.done()
```

**Once you understand the simple version, try this more realistic tree with random variations and leaves:**

```python
import turtle
import random

t = turtle.Turtle()
t.speed(0)
t.left(90)  # Point upward
t.penup()
t.goto(0, -200)
t.pendown()

def draw_tree(branch_len, t):
    \"\"\"Draw a recursive tree\"\"\"
    if branch_len > 5:  # Base case: stop when branches get too small
        # Draw this branch
        t.pensize(branch_len / 10)  # Thicker for bigger branches
        t.forward(branch_len)

        # Right branch
        t.right(25)
        draw_tree(branch_len - random.randint(10, 20), t)  # Shorter branch

        # Left branch
        t.left(50)
        draw_tree(branch_len - random.randint(10, 20), t)  # Shorter branch

        # Return to center
        t.right(25)
        t.backward(branch_len)

# Draw the tree
t.color("brown")
draw_tree(100, t)

# Add leaves at the ends
def add_leaves(t):
    t.color("green")
    t.pensize(3)
    for _ in range(50):
        # Find end of a small branch
        t.penup()
        t.goto(random.randint(-200, 200), random.randint(0, 200))
        t.pendown()
        t.dot(10, random.choice(["lightgreen", "darkgreen", "lime"]))

add_leaves(t)

t.hideturtle()
turtle.done()
```

**Nature Connection**: Real trees grow like this! Each branch splits into smaller branches.
"""

# Replace lines
lines[start:end+1] = [new_content]

with open('sessions/session10/session10.md', 'w') as f:
    f.writelines(lines)

print("Updated session10.md")