#!/usr/bin/env python3
"""
Fix break points in session01 and session02 after botched script run.
Removes all existing break markers and adds correct ones.
"""

import os
import re

def remove_break_markers(content):
    """Remove all break markers from content."""
    # Pattern for break marker: --- + blank line + break text + blank line + ---
    # We'll remove the entire block including surrounding blank lines carefully
    lines = content.split('\n')
    i = 0
    while i < len(lines):
        if lines[i] == "---" and i+1 < len(lines) and lines[i+1] == "":
            # Potential start of break marker
            # Look for next "---"
            j = i + 2
            while j < len(lines) and not (lines[j] == "---" and (j+1 >= len(lines) or lines[j+1] == "" or lines[j+1].startswith("#"))):
                j += 1
            if j < len(lines) and lines[j] == "---":
                # Check if line i+2 contains "⏱️"
                if i+2 < len(lines) and "⏱️" in lines[i+2]:
                    # Remove from i to j (inclusive)
                    del lines[i:j+1]
                    continue
        i += 1
    return '\n'.join(lines)

def add_break_before_heading(content, heading_pattern, message):
    """Add break marker before a specific heading."""
    lines = content.split('\n')
    for i in range(len(lines)):
        if re.match(heading_pattern, lines[i]):
            # Insert break before this line
            break_text = f"""---

⏱️ **20-Minute Break Point**

*{message}*

---"""
            lines.insert(i, break_text)
            return '\n'.join(lines)
    return content

def fix_parent_note(content):
    """Fix duplicated parent note."""
    # Find parent note line
    lines = content.split('\n')
    for i in range(len(lines)):
        if lines[i].startswith("*Parent Note:"):
            # Remove duplicate phrase
            line = lines[i]
            # Remove duplicate "This session is designed in 20-minute chunks..."
            # Simple: replace with standard note
            lines[i] = "*Parent Note: This session is designed in 20-minute chunks (marked with ⏱️ break points). Total session time: 45-60 minutes. Let your child explore and make mistakes - debugging is an important skill! The most important goal is maintaining excitement and curiosity.*"
            break
    return '\n'.join(lines)

def process_file(filepath):
    with open(filepath, 'r') as f:
        content = f.read()

    # Remove all existing breaks
    content = remove_break_markers(content)

    # Add breaks at correct positions
    # For session01:
    if "session01" in filepath:
        # Break after setup (before "## 📍 The Coordinate System")
        content = add_break_before_heading(content, r'^## 📍 The Coordinate System$',
                                           "Great job! You've set up Python and Thonny. Take a short break if you need one. When you're ready, continue with the next section to learn about coordinates and basic turtle commands.")
        # Break after first program (before "## 🧩 Why 90 Degrees?")
        content = add_break_before_heading(content, r'^## 🧩 Why 90 Degrees\?$',
                                           "Excellent! You've drawn your first square with Python. Take a short break if you need one. When you're ready, continue with the next section to learn about angles and hands-on exercises.")
        # Break after math connection (before "## 🎯 Scratch to Python Translation")
        content = add_break_before_heading(content, r'^## 🎯 Scratch to Python Translation$',
                                           "Great work! You've explored geometry concepts and hands-on exercises. Take a short break if you need one. When you're ready, continue with the Scratch to Python translation and challenge problems.")
        # Fix parent note
        content = fix_parent_note(content)

    elif "session02" in filepath:
        # Break before first exercise heading (## ✨ Hands-on Exercise: Scalable Shapes)
        content = add_break_before_heading(content, r'^## ✨ Hands-on Exercise: Scalable Shapes$',
                                           "Great! You've learned the basics of variables. Take a short break if you need one. When you're ready, continue with hands-on exercises to practice using variables with turtle graphics.")
        # Break before math connection
        content = add_break_before_heading(content, r'^## 🧠 Math Connection: Algebra Comes Alive!$',
                                           "Great job! You've practiced using variables with hands-on exercises. Take a short break if you need one. When you're ready, continue with the math connection and Scratch translation.")
        # Break before challenge problems
        content = add_break_before_heading(content, r'^## 🏆 Challenge Problems$',
                                           "Great work! You've learned about variables and their connections to algebra. Take a short break if you need one. When you're ready, try the challenge problems to test your skills!")
        # Fix parent note
        lines = content.split('\n')
        for i in range(len(lines)):
            if lines[i].startswith("*Parent Note:"):
                lines[i] = "*Parent Note: This session is designed in 20-minute chunks (marked with ⏱️ break points). Total session time: 45-60 minutes. The equal sign (`=`) as assignment is different from math equality - emphasize this distinction. Encourage experimentation with different values.*"
                break
        content = '\n'.join(lines)

    with open(filepath, 'w') as f:
        f.write(content)
    print(f"Fixed {filepath}")

if __name__ == "__main__":
    process_file("sessions/session01/session01.md")
    process_file("sessions/session02/session02.md")