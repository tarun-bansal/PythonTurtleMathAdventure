#!/usr/bin/env python3
"""
Script to add 20-minute break points to session markdown files.
Adds break points before:
1. First hands-on exercise heading (variations)
2. Math Connection heading
3. Challenge Problems heading
Also updates parent note at the end.
"""

import os
import re
import sys

SESSION_DIR = "sessions"
BREAK_MARKER = """---

⏱️ **20-Minute Break Point**

*{message}*

---"""

BREAK_MESSAGES = {
    "hands_on": "Great! You've learned the core concepts. Take a short break if you need one. When you're ready, continue with hands-on exercises to practice your new skills.",
    "math": "Great job! You've practiced with hands-on exercises. Take a short break if you need one. When you're ready, continue with the math connection and Scratch translation.",
    "challenge": "Great work! You've learned the key concepts. Take a short break if you need one. When you're ready, try the challenge problems to test your skills!"
}

PARENT_NOTE_PATTERN = r"\*Parent Note:.*\*"
PARENT_NOTE_REPLACEMENT = "*Parent Note: This session is designed in 20-minute chunks (marked with ⏱️ break points). Total session time: 45-60 minutes."

def add_break_points(content):
    """Add break points to session content."""
    lines = content.split('\n')
    modified = False

    # Find headings and insert break points
    # We'll work backwards to avoid messing up line numbers
    i = 0
    while i < len(lines):
        line = lines[i]

        # Check for hands-on exercise heading (variations)
        if re.match(r'^## .*[Hh]ands?-?[Oo]n [Ee]xercise', line) or \
           re.match(r'^## .*[Ee]xercise', line):
            # Ensure we haven't already inserted a break before this heading
            if i > 0 and "⏱️ **20-Minute Break Point**" not in lines[i-1]:
                # Insert break before this line
                break_text = BREAK_MARKER.format(message=BREAK_MESSAGES["hands_on"])
                lines.insert(i, break_text)
                i += break_text.count('\n') + 1
                modified = True

        # Check for math connection heading
        elif re.match(r'^## .*[Mm]ath [Cc]onnection', line):
            if i > 0 and "⏱️ **20-Minute Break Point**" not in lines[i-1]:
                break_text = BREAK_MARKER.format(message=BREAK_MESSAGES["math"])
                lines.insert(i, break_text)
                i += break_text.count('\n') + 1
                modified = True

        # Check for challenge problems heading
        elif re.match(r'^## .*[Cc]hallenge [Pp]roblems', line):
            if i > 0 and "⏱️ **20-Minute Break Point**" not in lines[i-1]:
                break_text = BREAK_MARKER.format(message=BREAK_MESSAGES["challenge"])
                lines.insert(i, break_text)
                i += break_text.count('\n') + 1
                modified = True

        i += 1

    # Update parent note at the end
    for i in range(len(lines)-1, -1, -1):
        if re.match(PARENT_NOTE_PATTERN, lines[i]):
            lines[i] = PARENT_NOTE_REPLACEMENT + " " + lines[i][len("*Parent Note: "):]
            modified = True
            break

    return '\n'.join(lines), modified

def process_session(session_num):
    """Process a single session file."""
    session_file = os.path.join(SESSION_DIR, f"session{session_num:02d}", f"session{session_num:02d}.md")
    if not os.path.exists(session_file):
        print(f"Warning: {session_file} not found")
        return

    with open(session_file, 'r') as f:
        content = f.read()

    new_content, modified = add_break_points(content)

    if modified:
        with open(session_file, 'w') as f:
            f.write(new_content)
        print(f"Processed session{session_num:02d}.md")
    else:
        print(f"No changes needed for session{session_num:02d}.md")

def main():
    """Process all sessions."""
    for session_num in range(1, 13):
        process_session(session_num)
    print("Done!")

if __name__ == "__main__":
    main()